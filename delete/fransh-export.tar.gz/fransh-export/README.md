# Пакет интеграции каталогов для франшизы MEDUSA

## 📦 Содержимое пакета

Этот пакет содержит все необходимое для интеграции системы каталогов магазинов в проект франшизы.

### Файлы в пакете:

1. **terehin_n.cloud.mda-medusa.ru.p12**
   - Клиентский сертификат для подключения к Balance API
   - Пароль: `000000000` (9 нулей)
   - Используется для авторизации на уровне SSL/TLS

2. **CATALOG_INTEGRATION_GUIDE.md**
   - Полное руководство по интеграции
   - Описание архитектуры и логики работы
   - Примеры кода и API endpoints
   - Рекомендации по безопасности

3. **QUICK_START_FRANSH.md**
   - Быстрая инструкция для старта
   - Минимальный набор изменений
   - Пошаговая настройка
   - Решение частых проблем

4. **database_setup.sql**
   - SQL миграция для создания таблиц
   - Индексы и оптимизация
   - Полезные функции и представления
   - Примеры данных

5. **test_fransh_connection.js**
   - Тестовый скрипт для проверки подключения
   - Диагностика проблем
   - Валидация сертификата
   - Анализ ответов API

6. **README.md** (этот файл)
   - Общее описание пакета
   - Быстрый старт
   - Структура проекта

## 🚀 Быстрый старт

### Шаг 1: Установка зависимостей

```bash
npm install axios node-forge node-cron
```

### Шаг 2: Копирование сертификата

```bash
# Создайте директорию для сертификатов
mkdir -p routes/certs

# Скопируйте сертификат
cp terehin_n.cloud.mda-medusa.ru.p12 routes/certs/
```

### Шаг 3: Настройка базы данных

```bash
# Выполните SQL миграцию
psql -U your_user -d your_database -f database_setup.sql
```

### Шаг 4: Тестирование подключения

```bash
# Запустите тестовый скрипт
node test_fransh_connection.js
```

Если тест прошел успешно - можно переходить к интеграции!

## 🔧 Основные изменения для франшизы

### URL API

**Было (mda-trade):**
```
https://cloud.mda-medusa.ru/mda-trade/hs/Api/BalanceData
```

**Стало (fransh-trade):**
```
https://cloud.mda-medusa.ru/fransh-trade/hs/Api/BalanceData
```

### Конфигурация

```javascript
const BALANCE_API_CONFIG = {
  username: 'ТерехинНА',
  password: '123455123',
  apiUrl: 'https://cloud.mda-medusa.ru/fransh-trade/hs/Api/BalanceData',
  credentials: Buffer.from('ТерехинНА:123455123').toString('base64')
};
```

**Остальное остается без изменений!**

## 📚 Документация

### Основные документы (читать в порядке):

1. **README.md** ← Вы здесь
2. **QUICK_START_FRANSH.md** - начните отсюда
3. **CATALOG_INTEGRATION_GUIDE.md** - подробная документация
4. **database_setup.sql** - структура БД
5. **test_fransh_connection.js** - тестирование

## 🏗️ Архитектура

```
┌─────────────────┐
│  Франш. проект  │
│   (Backend)     │
└────────┬────────┘
         │
         │ HTTPS + Client Certificate
         │
         ▼
┌─────────────────┐
│   Balance API   │
│  (fransh-trade) │
│      1С         │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  PostgreSQL     │
│  (catalog_*)    │
└─────────────────┘
```

## 🔐 Безопасность

### ⚠️ Важно!

1. **НЕ коммитить** сертификат в публичный репозиторий!
2. **НЕ хранить** пароли в коде (использовать .env)
3. **Ограничить доступ** к сертификату:
   ```bash
   chmod 600 routes/certs/terehin_n.cloud.mda-medusa.ru.p12
   ```

### Рекомендуемый .gitignore

```gitignore
# Сертификаты
routes/certs/*.p12
*.p12

# Конфигурация
.env
.env.local
```

## 📊 Таблицы базы данных

После выполнения миграции будут созданы:

1. **shop_locations** - магазины франшизы
2. **catalog_products** - товары из каталогов
3. **catalog_exclusions** - исключения (опционально)

## 🔄 Автоматическое обновление

Система автоматически обновляет каталоги:
- **При старте**: через 10 секунд
- **По расписанию**: каждые 30 минут
- **Вручную**: через API endpoint

## 📡 API Endpoints

После интеграции будут доступны:

```
GET  /api/catalog/shops                    # Список магазинов
GET  /api/catalog/shop/:id                 # Каталог магазина
GET  /api/catalog/search-products?q=...    # Поиск товаров
POST /api/catalog/update-catalogs          # Обновить каталоги
GET  /api/catalog/catalogs-status          # Статус кэша
GET  /api/catalog/product/:id              # Информация о товаре
GET  /api/catalog/shop-products/:shopCode  # Товары магазина
```

## 🧪 Тестирование

### Проверка подключения

```bash
node test_fransh_connection.js
```

### Проверка через curl

```bash
# Проверка списка магазинов
curl http://localhost:5001/api/catalog/shops \
  -H "Authorization: Static YOUR_STATIC_TOKEN"

# Проверка каталога магазина
curl http://localhost:5001/api/catalog/shop/13 \
  -H "Authorization: Static YOUR_STATIC_TOKEN"
```

## 📝 Требования

### NPM пакеты

```json
{
  "dependencies": {
    "axios": "^1.6.0",
    "node-forge": "^1.3.1",
    "node-cron": "^3.0.3",
    "express": "^4.18.0",
    "pg": "^8.11.0"
  }
}
```

### Node.js версия

- **Минимум**: Node.js 16.x
- **Рекомендуется**: Node.js 18.x или 20.x

### PostgreSQL

- **Минимум**: PostgreSQL 12.x
- **Рекомендуется**: PostgreSQL 14.x или выше

## ⚙️ Настройка под свои нужды

### Изменение расписания обновления

В `catalog.js`:

```javascript
// Изменить с 30 минут на 15 минут
cron.schedule('*/15 * * * *', async () => {
  await updateAllCatalogs();
});
```

### Изменение времени кэширования

```javascript
// Изменить с 60 минут на 30 минут
const CATALOGS_CACHE_DURATION = 30 * 60 * 1000;
```

### Добавление своего магазина

```sql
INSERT INTO shop_locations (
  shop_code, 
  shop_name, 
  address, 
  city
) VALUES 
  ('YOUR_CODE', 'Ваш магазин', 'Адрес', 'Город');
```

## 🐛 Решение проблем

### Ошибка: "Сертификат не найден"

```bash
# Проверьте путь
ls -la routes/certs/terehin_n.cloud.mda-medusa.ru.p12

# Если файла нет - скопируйте
cp terehin_n.cloud.mda-medusa.ru.p12 routes/certs/
```

### Ошибка: "401 Unauthorized"

Проверьте credentials:
- Username: `ТерехинНА`
- Password: `123455123`

### Ошибка: "404 Not Found"

Проверьте URL:
- Должен быть `fransh-trade`, а не `mda-trade`
- Магазин должен существовать в базе fransh-trade

### Ошибка: "UNABLE_TO_GET_ISSUER_CERT"

Проблема с цепочкой сертификатов. Для тестирования можно:

```javascript
// Только для тестирования!
const httpsAgent = new https.Agent({
  rejectUnauthorized: false, // ⚠️ Небезопасно!
  cert: certificate,
  key: privateKey
});
```

## 📞 Поддержка

### Контакты

- Telegram: @sysrootix
- Email: support@medusa-franchise.com

### Документация

- Полное руководство: `CATALOG_INTEGRATION_GUIDE.md`
- Быстрый старт: `QUICK_START_FRANSH.md`

## 📅 Версия

- **Версия пакета**: 1.0
- **Дата создания**: 30 октября 2025
- **Совместимость**: fransh-trade API v1.x

## ✅ Чек-лист интеграции

- [ ] Установлены все npm пакеты
- [ ] Сертификат скопирован в `routes/certs/`
- [ ] Выполнена SQL миграция
- [ ] Изменен URL с `mda-trade` на `fransh-trade`
- [ ] Тест подключения пройден успешно
- [ ] Добавлены записи в `shop_locations`
- [ ] API endpoints работают корректно
- [ ] Настроено автоматическое обновление
- [ ] Добавлены правила в `.gitignore`
- [ ] Документирован процесс для команды

## 🎯 Следующие шаги

1. ✅ Прочитайте `QUICK_START_FRANSH.md`
2. ✅ Запустите `test_fransh_connection.js`
3. ✅ Выполните SQL миграцию
4. ✅ Интегрируйте код в свой проект
5. ✅ Протестируйте все endpoints
6. ✅ Настройте мониторинг и логирование

## 📜 Лицензия

Этот пакет предназначен для использования в рамках франшизы MEDUSA.
Все права защищены.

---

**Успешной интеграции! 🚀**

