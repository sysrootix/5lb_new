# Различия между MDA-Trade и Fransh-Trade

## Обзор

Оба API используют одну и ту же инфраструктуру и методы доступа, но работают с разными базами данных 1С.

## 🔑 Основное различие

### URL API

| Параметр | MDA-Trade (основная) | Fransh-Trade (франшиза) |
|----------|----------------------|-------------------------|
| **URL** | `https://cloud.mda-medusa.ru/mda-trade/hs/Api/BalanceData` | `https://cloud.mda-medusa.ru/fransh-trade/hs/Api/BalanceData` |
| **База данных** | Основная база MEDUSA | База франшиз MEDUSA |
| **Магазины** | Собственные магазины MEDUSA | Магазины франшиз |

### Что изменяется при миграции

```javascript
// ❌ БЫЛО (mda-trade)
const apiUrl = 'https://cloud.mda-medusa.ru/mda-trade/hs/Api/BalanceData';

// ✅ СТАЛО (fransh-trade)
const apiUrl = 'https://cloud.mda-medusa.ru/fransh-trade/hs/Api/BalanceData';
```

**Изменение:** `mda-trade` → `fransh-trade` в URL

## ✅ Что остается без изменений

### 1. Credentials (Учетные данные)

```javascript
const credentials = {
  username: 'ТерехинНА',
  password: '123455123'
};
```

### 2. Сертификат

- **Имя файла**: `terehin_n.cloud.mda-medusa.ru.p12`
- **Пароль**: `000000000` (9 нулей)
- **Формат**: PKCS#12

### 3. Формат запросов

```json
{
  "shop_id": "13",
  "type": "store_data"
}
```

### 4. Формат ответов

Структура ответа идентична:

```json
{
  "status": "success",
  "data": {
    "shopname": "Название магазина",
    "items": [
      {
        "id": "category_id",
        "name": "Категория",
        "items": [
          {
            "id": "product_id",
            "name": "Товар",
            "retail_price": 500,
            "quanty": 10
          }
        ]
      }
    ]
  }
}
```

### 5. Методы API

Все endpoints работают одинаково:
- `store_data` - получение каталога магазина
- Любые другие методы, поддерживаемые API

### 6. Архитектура и логика

- Использование HTTPS с клиентским сертификатом
- Basic Authentication
- Кэширование
- Автоматическое обновление
- Обработка ошибок

## 🏢 Различия в данных

### MDA-Trade (основная база)

**Содержит:**
- Собственные магазины сети MEDUSA
- История продаж головной компании
- Полный каталог всех товаров
- Централизованная аналитика

**Магазины:**
```
13 - Калинина 10 (Москва)
14 - Новослободская (Москва)
15 - Тверская (Москва)
...
```

### Fransh-Trade (база франшиз)

**Содержит:**
- Магазины франшиз
- История продаж франчайзи
- Каталог товаров для франшиз
- Отдельная аналитика по франшизам

**Магазины:**
```
F01 - Франшиза Казань
F02 - Франшиза Екатеринбург
F03 - Франшиза Новосибирск
...
```

*Примечание: коды магазинов могут отличаться*

## 🔄 Процесс миграции

### Шаг 1: Определение целевой базы

**Вопрос:** Для какого типа бизнеса нужна интеграция?

- **Собственные магазины MEDUSA** → используйте `mda-trade`
- **Франшизы MEDUSA** → используйте `fransh-trade`

### Шаг 2: Изменение конфигурации

Замените только URL в конфигурации:

```javascript
// config.js или .env

// ДЛЯ MDA-TRADE (собственные магазины)
BALANCE_API_URL=https://cloud.mda-medusa.ru/mda-trade/hs/Api/BalanceData

// ДЛЯ FRANSH-TRADE (франшизы)
BALANCE_API_URL=https://cloud.mda-medusa.ru/fransh-trade/hs/Api/BalanceData
```

### Шаг 3: Проверка подключения

Запустите тестовый скрипт:

```bash
node test_fransh_connection.js
```

### Шаг 4: Проверка данных

Убедитесь, что получаете корректные данные для ваших магазинов:

```bash
# Проверка каталога
curl -X POST https://cloud.mda-medusa.ru/fransh-trade/hs/Api/BalanceData \
  -H "Content-Type: application/json" \
  -H "Authorization: Basic VGVyZWhpbkFOOjEyMzQ1NTEyMw==" \
  --cert terehin_n.cloud.mda-medusa.ru.p12:000000000 \
  -d '{"shop_id":"YOUR_SHOP_CODE","type":"store_data"}'
```

## 🔍 Как понять, какая база нужна?

### Проверьте коды магазинов

1. Запросите список ваших магазинов у администратора
2. Попробуйте получить каталог через API

**Если магазин найден в fransh-trade:**
```json
{
  "status": "success",
  "data": {
    "shopname": "Ваш магазин",
    "items": [...]
  }
}
```

**Если магазин НЕ найден:**
```json
{
  "status": "error",
  "message": "Магазин не найден"
}
```

### Таблица выбора базы

| Критерий | MDA-Trade | Fransh-Trade |
|----------|-----------|--------------|
| Тип бизнеса | Собственные магазины | Франшиза |
| Владелец магазина | MEDUSA | Франчайзи |
| Договор | Трудовой или ГПХ | Договор франшизы |
| Бухгалтерия | Централизованная | Собственная |
| Код магазина | 10-99 | F01-F99 или другой |

## ⚙️ Одновременная работа с двумя базами

Если ваш проект должен работать с обеими базами:

```javascript
const API_CONFIGS = {
  mda: {
    url: 'https://cloud.mda-medusa.ru/mda-trade/hs/Api/BalanceData',
    username: 'ТерехинНА',
    password: '123455123'
  },
  fransh: {
    url: 'https://cloud.mda-medusa.ru/fransh-trade/hs/Api/BalanceData',
    username: 'ТерехинНА',
    password: '123455123'
  }
};

// Функция выбора базы по коду магазина
function getApiConfig(shopCode) {
  if (shopCode.startsWith('F')) {
    return API_CONFIGS.fransh;
  }
  return API_CONFIGS.mda;
}

// Пример использования
async function getCatalog(shopCode) {
  const config = getApiConfig(shopCode);
  return await sendBalanceRequest(shopCode, config);
}
```

## 📊 Сравнительная таблица

| Параметр | MDA-Trade | Fransh-Trade | Примечание |
|----------|-----------|--------------|------------|
| **Домен** | cloud.mda-medusa.ru | cloud.mda-medusa.ru | Одинаковый |
| **База** | mda-trade | fransh-trade | **РАЗЛИЧАЕТСЯ** |
| **Username** | ТерехинНА | ТерехинНА | Одинаковый |
| **Password** | 123455123 | 123455123 | Одинаковый |
| **Сертификат** | terehin_n.cloud.mda-medusa.ru.p12 | terehin_n.cloud.mda-medusa.ru.p12 | Одинаковый |
| **Пароль сертификата** | 000000000 | 000000000 | Одинаковый |
| **Формат запроса** | JSON | JSON | Одинаковый |
| **Формат ответа** | JSON | JSON | Одинаковый |
| **Структура данных** | Иерархическая | Иерархическая | Одинаковая |

## 🎯 Рекомендации

### Для собственных магазинов MEDUSA
```javascript
const apiUrl = 'https://cloud.mda-medusa.ru/mda-trade/hs/Api/BalanceData';
```

### Для франшиз MEDUSA
```javascript
const apiUrl = 'https://cloud.mda-medusa.ru/fransh-trade/hs/Api/BalanceData';
```

### Универсальное решение
```javascript
const API_BASE = process.env.API_TYPE === 'franchise' 
  ? 'https://cloud.mda-medusa.ru/fransh-trade/hs/Api/BalanceData'
  : 'https://cloud.mda-medusa.ru/mda-trade/hs/Api/BalanceData';
```

## 🔐 Безопасность

### Общие рекомендации для обеих баз

1. **Не коммитить** credentials в репозиторий
2. **Использовать** переменные окружения
3. **Ограничить доступ** к сертификату
4. **Логировать** все запросы к API
5. **Мониторить** ошибки подключения

## 📞 Поддержка

### Вопросы по выбору базы

Если не уверены, какую базу использовать:
1. Обратитесь к администратору системы
2. Напишите в поддержку: @sysrootix
3. Проверьте ваш договор с MEDUSA

### Технические вопросы

- Telegram: @sysrootix
- Email: support@medusa-franchise.com

## 📝 Итоговая памятка

### Что нужно знать

1. **Различие ТОЛЬКО в URL** (mda-trade vs fransh-trade)
2. **Всё остальное идентично** (credentials, сертификат, формат)
3. **Нельзя получить** данные франшизы из mda-trade
4. **Нельзя получить** данные собственных магазинов из fransh-trade
5. **Можно использовать** обе базы одновременно

### Быстрая замена

```bash
# В вашем коде найдите:
mda-trade

# И замените на:
fransh-trade
```

Вот и всё! 🎉

---

**Дата создания:** 30 октября 2025  
**Версия:** 1.0  
**Проект:** MEDUSA Franchise Integration

