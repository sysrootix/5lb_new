-- =====================================================
-- SQL миграция для системы каталогов франшизы
-- Дата: 30 октября 2025
-- Проект: Франшиза MEDUSA
-- =====================================================

-- =====================================================
-- 1. Таблица магазинов (shop_locations)
-- =====================================================

CREATE TABLE IF NOT EXISTS shop_locations (
  shop_code VARCHAR(20) PRIMARY KEY,
  shop_name VARCHAR(200) NOT NULL,
  address VARCHAR(500),
  city VARCHAR(100) DEFAULT 'Москва',
  description TEXT,
  phone VARCHAR(20),
  working_hours VARCHAR(200),
  twogis_url VARCHAR(500),
  yandex_maps_url VARCHAR(500),
  google_maps_url VARCHAR(500),
  priority_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Комментарии к полям
COMMENT ON TABLE shop_locations IS 'Таблица магазинов франшизы';
COMMENT ON COLUMN shop_locations.shop_code IS 'Уникальный код магазина (используется для связи с 1С)';
COMMENT ON COLUMN shop_locations.shop_name IS 'Короткое название магазина';
COMMENT ON COLUMN shop_locations.address IS 'Полный адрес магазина';
COMMENT ON COLUMN shop_locations.city IS 'Город расположения магазина';
COMMENT ON COLUMN shop_locations.description IS 'Описание магазина';
COMMENT ON COLUMN shop_locations.phone IS 'Контактный телефон магазина';
COMMENT ON COLUMN shop_locations.working_hours IS 'Режим работы (например: "ПН-ВС 10:00-22:00")';
COMMENT ON COLUMN shop_locations.twogis_url IS 'Ссылка на 2GIS';
COMMENT ON COLUMN shop_locations.yandex_maps_url IS 'Ссылка на Яндекс.Карты';
COMMENT ON COLUMN shop_locations.google_maps_url IS 'Ссылка на Google Maps';
COMMENT ON COLUMN shop_locations.priority_order IS 'Порядок сортировки в списке (меньше = выше)';
COMMENT ON COLUMN shop_locations.is_active IS 'Активен ли магазин';

-- Индексы
CREATE INDEX IF NOT EXISTS idx_shop_locations_active ON shop_locations(is_active);
CREATE INDEX IF NOT EXISTS idx_shop_locations_city ON shop_locations(city);
CREATE INDEX IF NOT EXISTS idx_shop_locations_priority ON shop_locations(priority_order);

-- =====================================================
-- 2. Таблица товаров (catalog_products)
-- =====================================================

CREATE TABLE IF NOT EXISTS catalog_products (
  id VARCHAR(50) NOT NULL,
  name VARCHAR(500) NOT NULL,
  category_name VARCHAR(200),
  category_id VARCHAR(50),
  retail_price DECIMAL(10,2),
  quanty DECIMAL(10,3),
  characteristics JSONB,
  modifications JSONB,
  shop_code VARCHAR(20) NOT NULL,
  shop_name VARCHAR(200),
  is_active BOOLEAN DEFAULT TRUE,
  last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id, shop_code),
  FOREIGN KEY (shop_code) REFERENCES shop_locations(shop_code) ON DELETE CASCADE
);

-- Комментарии к полям
COMMENT ON TABLE catalog_products IS 'Таблица товаров из каталогов магазинов';
COMMENT ON COLUMN catalog_products.id IS 'ID товара из 1С (уникален в рамках магазина)';
COMMENT ON COLUMN catalog_products.name IS 'Название товара';
COMMENT ON COLUMN catalog_products.category_name IS 'Название категории товара';
COMMENT ON COLUMN catalog_products.category_id IS 'ID категории товара';
COMMENT ON COLUMN catalog_products.retail_price IS 'Розничная цена';
COMMENT ON COLUMN catalog_products.quanty IS 'Количество на складе';
COMMENT ON COLUMN catalog_products.characteristics IS 'Характеристики товара (JSON: {вкус: [...], цвет: [...]})';
COMMENT ON COLUMN catalog_products.modifications IS 'Модификации товара (JSON: [{id, name, quanty, retail_price}])';
COMMENT ON COLUMN catalog_products.shop_code IS 'Код магазина';
COMMENT ON COLUMN catalog_products.shop_name IS 'Название магазина';
COMMENT ON COLUMN catalog_products.is_active IS 'Активен ли товар (присутствует в последнем обновлении)';
COMMENT ON COLUMN catalog_products.last_updated IS 'Время последнего обновления';

-- Индексы для быстрого поиска
CREATE INDEX IF NOT EXISTS idx_catalog_products_shop ON catalog_products(shop_code);
CREATE INDEX IF NOT EXISTS idx_catalog_products_name ON catalog_products USING gin(to_tsvector('russian', name));
CREATE INDEX IF NOT EXISTS idx_catalog_products_category ON catalog_products(category_id);
CREATE INDEX IF NOT EXISTS idx_catalog_products_active ON catalog_products(is_active);
CREATE INDEX IF NOT EXISTS idx_catalog_products_updated ON catalog_products(last_updated);

-- Индекс для JSONB полей (для поиска по характеристикам)
CREATE INDEX IF NOT EXISTS idx_catalog_products_characteristics ON catalog_products USING gin(characteristics);
CREATE INDEX IF NOT EXISTS idx_catalog_products_modifications ON catalog_products USING gin(modifications);

-- =====================================================
-- 3. Таблица исключений каталога (catalog_exclusions)
-- =====================================================

CREATE TABLE IF NOT EXISTS catalog_exclusions (
  id SERIAL PRIMARY KEY,
  exclusion_type VARCHAR(20) NOT NULL CHECK (exclusion_type IN ('product', 'category')),
  item_id VARCHAR(50) NOT NULL,
  reason TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_by BIGINT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(exclusion_type, item_id)
);

-- Комментарии к полям
COMMENT ON TABLE catalog_exclusions IS 'Таблица исключений товаров/категорий из каталога';
COMMENT ON COLUMN catalog_exclusions.exclusion_type IS 'Тип исключения: product (товар) или category (категория)';
COMMENT ON COLUMN catalog_exclusions.item_id IS 'ID товара или категории для исключения';
COMMENT ON COLUMN catalog_exclusions.reason IS 'Причина исключения';
COMMENT ON COLUMN catalog_exclusions.is_active IS 'Активно ли исключение';
COMMENT ON COLUMN catalog_exclusions.created_by IS 'ID пользователя, создавшего исключение';

-- Индексы
CREATE INDEX IF NOT EXISTS idx_catalog_exclusions_type ON catalog_exclusions(exclusion_type);
CREATE INDEX IF NOT EXISTS idx_catalog_exclusions_active ON catalog_exclusions(is_active);

-- =====================================================
-- 4. Примеры данных (опционально)
-- =====================================================

-- Вставка тестового магазина (замените на реальные данные)
INSERT INTO shop_locations (
  shop_code, 
  shop_name, 
  address, 
  city, 
  phone, 
  working_hours,
  priority_order
) VALUES 
  ('13', 'Калинина 10', 'г. Москва, ул. Калинина, д. 10', 'Москва', '+7 (495) 123-45-67', 'ПН-ВС 10:00-22:00', 1)
ON CONFLICT (shop_code) DO NOTHING;

-- =====================================================
-- 5. Функции и триггеры для автоматизации
-- =====================================================

-- Функция для автоматического обновления updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Триггер для shop_locations
DROP TRIGGER IF EXISTS update_shop_locations_updated_at ON shop_locations;
CREATE TRIGGER update_shop_locations_updated_at
  BEFORE UPDATE ON shop_locations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 6. Представления (Views) для удобного доступа
-- =====================================================

-- Представление: Активные товары всех магазинов
CREATE OR REPLACE VIEW v_active_products AS
SELECT 
  cp.id,
  cp.name,
  cp.category_name,
  cp.retail_price,
  cp.quanty,
  cp.characteristics,
  cp.modifications,
  sl.shop_code,
  sl.shop_name,
  sl.city,
  sl.address,
  cp.last_updated
FROM catalog_products cp
JOIN shop_locations sl ON cp.shop_code = sl.shop_code
WHERE cp.is_active = TRUE AND sl.is_active = TRUE;

COMMENT ON VIEW v_active_products IS 'Активные товары во всех активных магазинах';

-- Представление: Статистика по магазинам
CREATE OR REPLACE VIEW v_shop_statistics AS
SELECT 
  sl.shop_code,
  sl.shop_name,
  sl.city,
  COUNT(cp.id) as total_products,
  COUNT(CASE WHEN cp.quanty > 0 THEN 1 END) as in_stock_products,
  MAX(cp.last_updated) as last_catalog_update
FROM shop_locations sl
LEFT JOIN catalog_products cp ON sl.shop_code = cp.shop_code AND cp.is_active = TRUE
WHERE sl.is_active = TRUE
GROUP BY sl.shop_code, sl.shop_name, sl.city;

COMMENT ON VIEW v_shop_statistics IS 'Статистика товаров по магазинам';

-- =====================================================
-- 7. Функции для работы с каталогом
-- =====================================================

-- Функция поиска товаров по названию
CREATE OR REPLACE FUNCTION search_products(search_query TEXT)
RETURNS TABLE (
  product_id VARCHAR,
  product_name VARCHAR,
  category_name VARCHAR,
  retail_price DECIMAL,
  quantity DECIMAL,
  shop_code VARCHAR,
  shop_name VARCHAR,
  city VARCHAR
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    cp.id,
    cp.name,
    cp.category_name,
    cp.retail_price,
    cp.quanty,
    sl.shop_code,
    sl.shop_name,
    sl.city
  FROM catalog_products cp
  JOIN shop_locations sl ON cp.shop_code = sl.shop_code
  WHERE 
    cp.is_active = TRUE 
    AND sl.is_active = TRUE
    AND to_tsvector('russian', cp.name) @@ plainto_tsquery('russian', search_query)
  ORDER BY 
    ts_rank(to_tsvector('russian', cp.name), plainto_tsquery('russian', search_query)) DESC,
    cp.name;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION search_products IS 'Полнотекстовый поиск товаров по названию';

-- =====================================================
-- 8. Очистка старых неактивных товаров (maintenance)
-- =====================================================

-- Функция для удаления старых неактивных товаров (старше 30 дней)
CREATE OR REPLACE FUNCTION cleanup_inactive_products()
RETURNS INTEGER AS $$
DECLARE
  deleted_count INTEGER;
BEGIN
  DELETE FROM catalog_products
  WHERE is_active = FALSE 
    AND last_updated < CURRENT_TIMESTAMP - INTERVAL '30 days';
  
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION cleanup_inactive_products IS 'Удаляет неактивные товары старше 30 дней';

-- Запланированная очистка (если используется pg_cron)
-- SELECT cron.schedule('cleanup_inactive_products', '0 3 * * 0', 'SELECT cleanup_inactive_products();');

-- =====================================================
-- 9. Права доступа (настройте под свои нужды)
-- =====================================================

-- Создание роли для приложения (опционально)
-- CREATE ROLE catalog_app WITH LOGIN PASSWORD 'your_secure_password';

-- Предоставление прав на таблицы
-- GRANT SELECT, INSERT, UPDATE, DELETE ON catalog_products TO catalog_app;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON shop_locations TO catalog_app;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON catalog_exclusions TO catalog_app;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO catalog_app;

-- =====================================================
-- 10. Полезные запросы для проверки
-- =====================================================

-- Проверка количества товаров в каждом магазине
-- SELECT shop_code, shop_name, COUNT(*) as products_count 
-- FROM catalog_products 
-- WHERE is_active = TRUE 
-- GROUP BY shop_code, shop_name;

-- Проверка последнего обновления каталогов
-- SELECT shop_code, shop_name, MAX(last_updated) as last_update 
-- FROM catalog_products 
-- GROUP BY shop_code, shop_name;

-- Поиск товаров с модификациями
-- SELECT name, shop_name, modifications 
-- FROM catalog_products 
-- WHERE modifications IS NOT NULL AND is_active = TRUE 
-- LIMIT 10;

-- Товары с характеристиками
-- SELECT name, shop_name, characteristics 
-- FROM catalog_products 
-- WHERE characteristics IS NOT NULL AND is_active = TRUE 
-- LIMIT 10;

-- =====================================================
-- КОНЕЦ МИГРАЦИИ
-- =====================================================

